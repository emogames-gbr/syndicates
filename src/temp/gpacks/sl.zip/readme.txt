Installationsanleitung f�r das Syndicates-Grafickpaket:

1. Zip-Datei in ein beliebiges Verzeichnis auf der eigenen Festplatte entpacken.
2. In Syndicates unter -> Optionen den "Pfad zum lokalen Grafikset:" eintragen.

Beispiel f�r Windows Nutzer: "C:\beispiel\syndicates"
Beispiel f�r Linux Nutzer: "/beispiels/syndicates"


Wer den Mozilla Firebird benutzt, muss folgende Einstellung vornehmen, um auf lokale Dateien zugreifen zu k�nnen:
Mozilla Firebird, bei der Adress-Bar "about :config" eintippen ohne die " und ohne Leerstelle. Dann auf 	"security.checkloaduri" gehen, und den Wert "true" durch "false" ersetzen.


Sollte es zu Problemen kommen, bitte eine E-Mail an
"support@syndicates-online.de" schreiben.


Scytale
